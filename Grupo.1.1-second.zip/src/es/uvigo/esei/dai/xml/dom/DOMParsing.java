package es.uvigo.esei.dai.xml.dom;


import java.io.File;
import java.io.FileWriter;

import java.io.IOException;

import java.io.StringWriter;

import javax.xml.XMLConstants;
import javax.xml.parsers.DocumentBuilder;
import javax.xml.parsers.DocumentBuilderFactory;
import javax.xml.parsers.ParserConfigurationException;
import javax.xml.transform.OutputKeys;
import javax.xml.transform.Transformer;
import javax.xml.transform.TransformerException;
import javax.xml.transform.TransformerFactory;
import javax.xml.transform.dom.DOMSource;
import javax.xml.transform.stream.StreamResult;
import javax.xml.transform.stream.StreamSource;
import javax.xml.validation.Schema;
import javax.xml.validation.SchemaFactory;

import org.w3c.dom.Document;
import org.xml.sax.InputSource;
import org.xml.sax.SAXException;

import es.uvigo.esei.dai.xml.SimpleErrorHandler;

public class DOMParsing {
	public static Document loadDocument(String documentPath) 
	throws ParserConfigurationException, SAXException, IOException {
		// Construcción del parser del documento
		DocumentBuilderFactory factory = DocumentBuilderFactory.newInstance();
		// factory.setNamespaceAware(true);
		
		DocumentBuilder builder = factory.newDocumentBuilder();
		
		// Parsing del documento
		return builder.parse(documentPath);
	}
	
	public static Document loadAndValidateWithInternalDTD(String documentPath) 
	throws ParserConfigurationException, SAXException, IOException {
		// Construcción del parser del documento activando validación
		DocumentBuilderFactory factory = DocumentBuilderFactory.newInstance();
		factory.setValidating(true);
		
		// Al construir el parser hay que añadir un manejador de errores
		DocumentBuilder builder = factory.newDocumentBuilder();
		builder.setErrorHandler(new SimpleErrorHandler());
		
		// Parsing y validación del documento
		return builder.parse(new File(documentPath));
	}
	
	public static Document loadAndValidateWithInternalXSD(String documentPath) 
	throws ParserConfigurationException, SAXException, IOException {
		// Construcción del parser del documento activando validación
		DocumentBuilderFactory factory = DocumentBuilderFactory.newInstance();
		factory.setValidating(true);
		factory.setNamespaceAware(true);
		factory.setAttribute(
			"http://java.sun.com/xml/jaxp/properties/schemaLanguage", 
			XMLConstants.W3C_XML_SCHEMA_NS_URI
		);
		
		// Al construir el parser hay que añadir un manejador de errores
		DocumentBuilder builder = factory.newDocumentBuilder();
		builder.setErrorHandler(new SimpleErrorHandler());
		
		// Parsing y validación del documento
		return builder.parse(new File(documentPath));
	}
	
	public static Document loadAndValidateWithExternalXSD(String documentPath, String schemaPath) 
	throws ParserConfigurationException, SAXException, IOException {
		// Construcción del schema
		System.out.println(">> "+schemaPath);
		SchemaFactory schemaFactory = 
			SchemaFactory.newInstance(XMLConstants.W3C_XML_SCHEMA_NS_URI);
		Schema schema = schemaFactory.newSchema(new File(schemaPath));
		
		// Construcción del parser del documento. Se establece el esquema y se activa
		// la validación y comprobación de namespaces
		DocumentBuilderFactory factory = DocumentBuilderFactory.newInstance();
		factory.setValidating(false);
		factory.setNamespaceAware(true);
		factory.setSchema(schema);
		
		// Se añade el manejador de errores
		DocumentBuilder builder = factory.newDocumentBuilder();
		builder.setErrorHandler(new SimpleErrorHandler());
		
		return builder.parse(new File(documentPath));
	}
	
	public static Document loadAndValidateWithExternalURL(String documentPath, String schemaPath) 
			throws ParserConfigurationException, SAXException, IOException {
				// Construcción del schema		

		File xml = new File("file.xml");
		File xsd = new File("file.xsd");
		FileWriter xmlWriter = new FileWriter(xml);
		FileWriter xsdWriter = new FileWriter(xsd);
		xmlWriter.write(documentPath);
		xmlWriter.flush();
		xmlWriter.close();
		xsdWriter.write(schemaPath);
		xsdWriter.flush();
		xsdWriter.close();
		
		SchemaFactory schemaFactory = 
			SchemaFactory.newInstance(XMLConstants.W3C_XML_SCHEMA_NS_URI);
		Schema schema = schemaFactory.newSchema(xsd);
		
		// Construcción del parser del documento. Se establece el esquema y se activa
		// la validación y comprobación de namespaces
		DocumentBuilderFactory factory = DocumentBuilderFactory.newInstance();
		factory.setValidating(false);
		factory.setNamespaceAware(true);
		factory.setSchema(schema);
		
		// Se añade el manejador de errores
		DocumentBuilder builder = factory.newDocumentBuilder();
		builder.setErrorHandler(new SimpleErrorHandler());
		Document document = builder.parse(xml); 
		xml.delete();
		xsd.delete();
		return document;
	}
	
	public static String toXML(Document document)
	throws TransformerException {
		// Creación y configuración del transformador. En este caso, se activa
		// la indentación del XML
		TransformerFactory factory = TransformerFactory.newInstance();
		factory.setAttribute("indent-number", 3);
		
		Transformer transformer = factory.newTransformer();
		transformer.setOutputProperty(OutputKeys.INDENT, "yes");
		
		// El resultado se almacenará en una cadena de texto
		StringWriter writer = new StringWriter();
		
		transformer.transform(
			new DOMSource(document),
			new StreamResult(writer)
		);
		
		return writer.toString();
	}
}
